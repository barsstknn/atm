using ATMSimulator.Backend.Models;

namespace ATMSimulator.Backend.Services
{
    public class AccountService : IAccountService
    {
        // In-memory storage for demonstration purposes
        // In a real application, this would be a database
        private static List<Account> _accounts = new List<Account>();
        private static List<Transaction> _transactions = new List<Transaction>();
        private static int _nextAccountId = 1;
        private static int _nextTransactionId = 1;

        public Account CreateAccount(int userId, string currency)
        {
            var account = new Account
            {
                Id = _nextAccountId++,
                UserId = userId,
                AccountNumber = GenerateAccountNumber(),
                Currency = currency,
                Balance = 0,
                CreditLimit = 0,
                AvailableCredit = 0,
                CreatedAt = DateTime.Now,
                IsActive = true
            };

            _accounts.Add(account);
            return account;
        }

        public Account GetAccountById(int id)
        {
            return _accounts.FirstOrDefault(a => a.Id == id);
        }

        public Account GetAccountByNumber(string accountNumber)
        {
            return _accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
        }

        public List<Account> GetAccountsByUserId(int userId)
        {
            return _accounts.Where(a => a.UserId == userId).ToList();
        }

        public Account UpdateBalance(int accountId, decimal amount, string transactionType)
        {
            var account = GetAccountById(accountId);
            if (account == null)
            {
                throw new Exception("Account not found");
            }

            // Update balance based on transaction type
            switch (transactionType.ToLower())
            {
                case "deposit":
                    account.Balance += amount;
                    break;
                case "withdrawal":
                    if (account.Balance < amount)
                    {
                        throw new Exception("Insufficient funds");
                    }
                    account.Balance -= amount;
                    break;
                default:
                    throw new Exception("Invalid transaction type");
            }

            // Record transaction
            var transaction = new Transaction
            {
                Id = _nextTransactionId++,
                AccountId = accountId,
                TransactionType = transactionType,
                Amount = amount,
                Currency = account.Currency,
                BalanceAfterTransaction = account.Balance,
                TransactionDate = DateTime.Now,
                Description = $"{transactionType} transaction"
            };

            _transactions.Add(transaction);

            return account;
        }

        public bool AccountExists(string accountNumber)
        {
            return _accounts.Any(a => a.AccountNumber == accountNumber);
        }

        private string GenerateAccountNumber()
        {
            // Generate a random 10-digit account number
            var random = new Random();
            var accountNumber = "";
            for (int i = 0; i < 10; i++)
            {
                accountNumber += random.Next(0, 10);
            }
            return accountNumber;
        }
    }
}