using ATMSimulator.Backend.Models;
using System.Security.Cryptography;
using System.Text;

namespace ATMSimulator.Backend.Services
{
    public class UserService : IUserService
    {
        // In-memory storage for demonstration purposes
        // In a real application, this would be a database
        private static List<User> _users = new List<User>();
        private static int _nextUserId = 1;

        public User RegisterUser(User user, string password)
        {
            // Check if user already exists
            if (UserExists(user.TcNumber))
            {
                throw new Exception("User with this TC number already exists");
            }

            // Hash the password
            user.PasswordHash = HashPassword(password);
            user.Id = _nextUserId++;
            user.CreatedAt = DateTime.Now;
            user.IsActive = true;

            _users.Add(user);
            return user;
        }

        public User AuthenticateUser(string tcNumber, string password)
        {
            var user = _users.FirstOrDefault(u => u.TcNumber == tcNumber);
            if (user == null)
            {
                return null;
            }

            // Verify password
            if (VerifyPassword(password, user.PasswordHash))
            {
                return user;
            }

            return null;
        }

        public User GetUserById(int id)
        {
            return _users.FirstOrDefault(u => u.Id == id);
        }

        public User GetUserByTcNumber(string tcNumber)
        {
            return _users.FirstOrDefault(u => u.TcNumber == tcNumber);
        }

        public bool UserExists(string tcNumber)
        {
            return _users.Any(u => u.TcNumber == tcNumber);
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashedBytes);
            }
        }

        private bool VerifyPassword(string password, string hash)
        {
            var hashedPassword = HashPassword(password);
            return hashedPassword == hash;
        }
    }
}