using ATMSimulator.Backend.Models;

namespace ATMSimulator.Backend.Services
{
    public interface IAccountService
    {
        Account CreateAccount(int userId, string currency);
        Account GetAccountById(int id);
        Account GetAccountByNumber(string accountNumber);
        List<Account> GetAccountsByUserId(int userId);
        Account UpdateBalance(int accountId, decimal amount, string transactionType);
        bool AccountExists(string accountNumber);
    }
}