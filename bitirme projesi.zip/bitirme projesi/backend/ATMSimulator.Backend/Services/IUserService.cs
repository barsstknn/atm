using ATMSimulator.Backend.Models;

namespace ATMSimulator.Backend.Services
{
    public interface IUserService
    {
        User RegisterUser(User user, string password);
        User AuthenticateUser(string tcNumber, string password);
        User GetUserById(int id);
        User GetUserByTcNumber(string tcNumber);
        bool UserExists(string tcNumber);
    }
}