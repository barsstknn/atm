using ATMSimulator.Backend.Models;
using ATMSimulator.Backend.Services;
using Microsoft.AspNetCore.Mvc;

namespace ATMSimulator.Backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly IAccountService _accountService;

        public UsersController(IUserService userService, IAccountService accountService)
        {
            _userService = userService;
            _accountService = accountService;
        }

        [HttpPost("register")]
        public IActionResult Register([FromBody] RegisterDto registerDto)
        {
            try
            {
                // Validate input
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                // Check if passwords match
                if (registerDto.Password != registerDto.ConfirmPassword)
                {
                    return BadRequest(new { message = "Passwords do not match" });
                }

                // Check if user already exists
                if (_userService.UserExists(registerDto.TcNumber))
                {
                    return BadRequest(new { message = "User with this TC number already exists" });
                }

                // Create user
                var user = new User
                {
                    FirstName = registerDto.FirstName,
                    LastName = registerDto.LastName,
                    TcNumber = registerDto.TcNumber,
                    SecurityQuestion = registerDto.SecurityQuestion,
                    SecurityAnswer = registerDto.SecurityAnswer
                };

                var createdUser = _userService.RegisterUser(user, registerDto.Password);

                // Create accounts for the user in different currencies
                _accountService.CreateAccount(createdUser.Id, "TRY");
                _accountService.CreateAccount(createdUser.Id, "USD");
                _accountService.CreateAccount(createdUser.Id, "EUR");

                return Ok(new { message = "User registered successfully", userId = createdUser.Id });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while registering the user", error = ex.Message });
            }
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginDto loginDto)
        {
            try
            {
                // Validate input
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                // Authenticate user
                var user = _userService.AuthenticateUser(loginDto.TcNumber, loginDto.Password);
                if (user == null)
                {
                    return Unauthorized(new { message = "Invalid TC number or password" });
                }

                // Get user accounts
                var accounts = _accountService.GetAccountsByUserId(user.Id);
                var accountDtos = accounts.Select(a => new AccountDto
                {
                    Id = a.Id,
                    AccountNumber = a.AccountNumber,
                    Currency = a.Currency,
                    Balance = a.Balance,
                    CreditLimit = a.CreditLimit,
                    AvailableCredit = a.AvailableCredit,
                    CreatedAt = a.CreatedAt
                }).ToList();

                return Ok(new { 
                    message = "Login successful", 
                    user = new { 
                        id = user.Id, 
                        firstName = user.FirstName, 
                        lastName = user.LastName,
                        tcNumber = user.TcNumber
                    },
                    accounts = accountDtos
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred during login", error = ex.Message });
            }
        }
    }
}