using ATMSimulator.Backend.Models;
using ATMSimulator.Backend.Services;
using Microsoft.AspNetCore.Mvc;

namespace ATMSimulator.Backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccountsController : ControllerBase
    {
        private readonly IAccountService _accountService;

        public AccountsController(IAccountService accountService)
        {
            _accountService = accountService;
        }

        [HttpGet("{accountNumber}")]
        public IActionResult GetAccount(string accountNumber)
        {
            try
            {
                var account = _accountService.GetAccountByNumber(accountNumber);
                if (account == null)
                {
                    return NotFound(new { message = "Account not found" });
                }

                var accountDto = new AccountDto
                {
                    Id = account.Id,
                    AccountNumber = account.AccountNumber,
                    Currency = account.Currency,
                    Balance = account.Balance,
                    CreditLimit = account.CreditLimit,
                    AvailableCredit = account.AvailableCredit,
                    CreatedAt = account.CreatedAt
                };

                return Ok(accountDto);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while retrieving the account", error = ex.Message });
            }
        }

        [HttpGet("user/{userId}")]
        public IActionResult GetAccountsByUserId(int userId)
        {
            try
            {
                var accounts = _accountService.GetAccountsByUserId(userId);
                var accountDtos = accounts.Select(a => new AccountDto
                {
                    Id = a.Id,
                    AccountNumber = a.AccountNumber,
                    Currency = a.Currency,
                    Balance = a.Balance,
                    CreditLimit = a.CreditLimit,
                    AvailableCredit = a.AvailableCredit,
                    CreatedAt = a.CreatedAt
                }).ToList();

                return Ok(accountDtos);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while retrieving the accounts", error = ex.Message });
            }
        }
    }
}