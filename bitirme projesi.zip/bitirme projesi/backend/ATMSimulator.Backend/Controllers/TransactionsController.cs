using ATMSimulator.Backend.Models;
using ATMSimulator.Backend.Services;
using Microsoft.AspNetCore.Mvc;

namespace ATMSimulator.Backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransactionsController : ControllerBase
    {
        private readonly IAccountService _accountService;

        public TransactionsController(IAccountService accountService)
        {
            _accountService = accountService;
        }

        [HttpPost("deposit")]
        public IActionResult Deposit([FromBody] TransactionDto transactionDto)
        {
            try
            {
                // Validate input
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                // Get account
                var account = _accountService.GetAccountByNumber(transactionDto.AccountNumber);
                if (account == null)
                {
                    return NotFound(new { message = "Account not found" });
                }

                // Perform deposit
                var updatedAccount = _accountService.UpdateBalance(account.Id, transactionDto.Amount, "deposit");

                return Ok(new { 
                    message = "Deposit successful", 
                    accountNumber = updatedAccount.AccountNumber,
                    newBalance = updatedAccount.Balance,
                    currency = updatedAccount.Currency
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred during deposit", error = ex.Message });
            }
        }

        [HttpPost("withdraw")]
        public IActionResult Withdraw([FromBody] TransactionDto transactionDto)
        {
            try
            {
                // Validate input
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                // Get account
                var account = _accountService.GetAccountByNumber(transactionDto.AccountNumber);
                if (account == null)
                {
                    return NotFound(new { message = "Account not found" });
                }

                // Perform withdrawal
                var updatedAccount = _accountService.UpdateBalance(account.Id, transactionDto.Amount, "withdrawal");

                return Ok(new { 
                    message = "Withdrawal successful", 
                    accountNumber = updatedAccount.AccountNumber,
                    newBalance = updatedAccount.Balance,
                    currency = updatedAccount.Currency
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred during withdrawal", error = ex.Message });
            }
        }
    }
}