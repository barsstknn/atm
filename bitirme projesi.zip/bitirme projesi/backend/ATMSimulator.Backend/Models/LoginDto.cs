namespace ATMSimulator.Backend.Models
{
    public class LoginDto
    {
        public string TcNumber { get; set; }
        public string Password { get; set; }
    }
}